## From AAAI2018 paper [Convolutional 2D Knowledge Graph Embeddings](https://arxiv.org/abs/1707.01476)
