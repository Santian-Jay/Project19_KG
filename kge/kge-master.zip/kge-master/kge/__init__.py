from kge.config import Config, Configurable
from kge.dataset import Dataset
