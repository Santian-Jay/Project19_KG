kge package
===========

Subpackages
-----------

.. toctree::

    kge.job
    kge.model
    kge.util

Submodules
----------

kge.config module
-----------------

.. automodule:: kge.config
    :members:
    :undoc-members:
    :show-inheritance:

kge.dataset module
------------------

.. automodule:: kge.dataset
    :members:
    :undoc-members:
    :show-inheritance:

kge.indexing module
-------------------

.. automodule:: kge.indexing
    :members:
    :undoc-members:
    :show-inheritance:

kge.misc module
---------------

.. automodule:: kge.misc
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: kge
    :members:
    :undoc-members:
    :show-inheritance:
