kge.model package
=================

Subpackages
-----------

.. toctree::

    kge.model.embedder

Submodules
----------

kge.model.complex module
------------------------

.. automodule:: kge.model.complex
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.conve module
----------------------

.. automodule:: kge.model.conve
    :members:
    :undoc-members:
    :show-inheritance:


kge.model.distmult module
-------------------------

.. automodule:: kge.model.distmult
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.kge\_model module
---------------------------

.. automodule:: kge.model.kge_model
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.reciprocal\_relations\_model module
---------------------------------------------

.. automodule:: kge.model.reciprocal_relations_model
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.rescal module
-----------------------

.. automodule:: kge.model.rescal
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.transe module
-----------------------

.. automodule:: kge.model.transe
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: kge.model
    :members:
    :undoc-members:
    :show-inheritance:
