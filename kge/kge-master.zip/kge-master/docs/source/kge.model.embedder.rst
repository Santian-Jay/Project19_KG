kge.model.embedder package
==========================

Submodules
----------

kge.model.embedder.lookup\_embedder module
------------------------------------------

.. automodule:: kge.model.embedder.lookup_embedder
    :members:
    :undoc-members:
    :show-inheritance:


kge.model.embedder.projection\_embedder module
----------------------------------------------

.. automodule:: kge.model.embedder.projection_embedder
    :members:
    :undoc-members:
    :show-inheritance:

kge.model.embedder.tucker3\_relation\_embedder module
-----------------------------------------------------

.. automodule:: kge.model.embedder.tucker3_relation_embedder
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: kge.model.embedder
    :members:
    :undoc-members:
    :show-inheritance:
