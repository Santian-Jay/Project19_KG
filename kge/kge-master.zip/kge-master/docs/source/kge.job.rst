kge.job package
===============

Submodules
----------

kge.job.auto\_search module
---------------------------

.. automodule:: kge.job.auto_search
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.ax\_search module
-------------------------

.. automodule:: kge.job.ax_search
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.entity\_pair\_ranking module
------------------------------------

.. automodule:: kge.job.entity_pair_ranking
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.entity\_ranking module
------------------------------

.. automodule:: kge.job.entity_ranking
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.eval module
-------------------

.. automodule:: kge.job.eval
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.grid\_search module
---------------------------

.. automodule:: kge.job.grid_search
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.job module
------------------

.. automodule:: kge.job.job
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.manual\_search module
-----------------------------

.. automodule:: kge.job.manual_search
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.search module
---------------------

.. automodule:: kge.job.search
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.trace module
--------------------

.. automodule:: kge.job.trace
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.train module
--------------------

.. automodule:: kge.job.train
    :members:
    :undoc-members:
    :show-inheritance:

kge.job.util module
-------------------

.. automodule:: kge.job.util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: kge.job
    :members:
    :undoc-members:
    :show-inheritance:
